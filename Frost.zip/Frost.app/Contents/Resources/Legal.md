## Mentions légales
Éditeur de Frost : Givre Studio. Responsable de la publication : Givre Studio.
Contact : frost-browser@proton.me — pour toute question, demande ou signalement (y compris de sécurité).
Hébergement des téléchargements et des mises à jour : GitHub, Inc., 88 Colin P. Kelly Jr. Street, San Francisco, CA 94107, États-Unis.
Le nom Frost, le logo, la mascotte Flocon, l'interface, le code et les textes sont protégés par le Code de la propriété intellectuelle. Les noms et logos de services tiers affichés dans Frost (par exemple dans Frost TV) appartiennent à leurs titulaires ; aucun partenariat n'existe avec ces services.
Dernière mise à jour de ces textes : 28 octobre 2026.

## Politique de confidentialité
Frost ne collecte aucune donnée personnelle : zéro télémétrie, zéro compte, zéro publicité, zéro revente (RGPD, loi Informatique et Libertés). Givre Studio n'a accès à aucune de vos données.
- Aucune statistique d'usage, aucun rapport de plantage, aucun identifiant d'appareil n'est envoyé.
- Historique, Logbook, onglets, favoris, signets, Notebook et statistiques du bouclier restent dans le dossier Application Support de votre Mac.
- Les mots de passe restent dans le Trousseau de macOS, sur ce Mac.
- Les conversations avec les Frostbots restent sur votre Mac ; le modèle d'IA (Apple Intelligence ou Ollama) tourne localement.
- Connexions établies par Frost lui-même : vérification et téléchargement des mises à jour (GitHub), icônes des sites (sans cookie), recherches web des Frostbots si vous les utilisez, téléchargement d'Ollama si vous le demandez. Aucune de ces connexions ne transporte de donnée personnelle.
Vos droits (RGPD, art. 15 à 21) s'exercent directement sur votre appareil : Réglages › Bouclier › Données efface tout. Pour toute question : frost-browser@proton.me. Vous pouvez aussi saisir la CNIL (www.cnil.fr).

## Conditions générales d'utilisation
Frost est un navigateur gratuit, édité par Givre Studio, sans compte et sans publicité ; l'utiliser vaut acceptation de ces conditions.
- Licence personnelle, gratuite, non exclusive et non transférable. Le code n'est pas publié ; la décompilation est interdite hors cas prévus par l'article L. 122-6-1 du CPI. Frost ne doit être téléchargé que depuis les sources officielles de Givre Studio.
- Mises à jour : Frost se met à jour automatiquement depuis les publications officielles de Givre Studio. Les correctifs de sécurité s'installent d'office, pour votre protection.
- Vous restez responsable de votre navigation et du respect des conditions des sites et services utilisés, y compris dans Frost TV, qui utilise vos propres comptes.
- Serveur local (Ollama / modèles tiers) : faire tourner de grands modèles de langage sur le Mac sollicite intensément le processeur, la mémoire unifiée et la batterie. Sur les machines à refroidissement passif (MacBook Air), cela peut entraîner une surchauffe, des ralentissements sévères ou des arrêts forcés du système. Cette option est réservée aux utilisateurs avertis disposant d'un matériel adapté (MacBook Pro avec ventilation active, Mac Studio, 16 Go de mémoire unifiée minimum). Givre Studio décline toute responsabilité quant aux instabilités système ou pertes de données causées par l'utilisation de modèles tiers non calibrés. Apple Intelligence reste le moteur conseillé.
- Les réponses des Frostbots peuvent être inexactes : vérifiez les informations importantes. Ils n'agissent dans vos pages que lorsque vous le leur demandez, ne remplissent jamais de mot de passe ni de donnée de paiement, et peuvent vous demander votre accord avant chaque action (Réglages › Frostbots).
- Frost est fourni en l'état ; rien ne limite les droits que la loi française accorde aux consommateurs.
- Droit français. En cas de désaccord, écrivez d'abord à frost-browser@proton.me pour trouver une solution amiable ; à défaut, les tribunaux français compétents.

## Politique cookies et traceurs
Frost et ses pages de téléchargement ne déposent aucun cookie ni traceur de mesure, de publicité ou de réseau social : aucun bandeau de consentement n'est nécessaire.
Les sites visités peuvent déposer leurs propres cookies, stockés sur votre Mac. Frost refuse automatiquement les bandeaux de consentement, bloque les cookies tiers et les domaines de pistage, retire les paramètres de pistage des liens, envoie le signal Global Privacy Control, et détruit les cookies de la navigation privée à la fermeture. Réglages › Bouclier permet de tout gérer et de tout effacer.
