## Legal notice
Publisher of Frost: Givre Studio. Publication director: Givre Studio.
Contact: frost-browser@proton.me — for any question, request or report (including security issues).
Downloads and updates are hosted by GitHub, Inc., 88 Colin P. Kelly Jr. Street, San Francisco, CA 94107, United States.
The Frost name, logo, the Flocon mascot, the interface, code and texts are protected by French intellectual property law. Third-party service names and logos shown in Frost (for example in Frost TV) belong to their owners; there is no partnership with these services.
These texts were last updated on October 28, 2026. The French version prevails.

## Privacy policy
Frost collects no personal data: zero telemetry, zero account, zero advertising, zero resale (GDPR). Givre Studio has no access to any of your data.
- No usage statistics, crash reports or device identifiers are sent.
- History, Logbook, tabs, favorites, bookmarks, Notebook and shield statistics stay in your Mac's Application Support folder.
- Passwords stay in the macOS Keychain, on this Mac.
- Conversations with the Frostbots stay on your Mac; the AI model (Apple Intelligence or Ollama) runs locally.
- Connections Frost makes on its own: checking for and downloading updates (GitHub), site icons (without cookies), Frostbots web searches if you use them, downloading Ollama if you ask for it. None of these connections carries personal data.
You exercise your GDPR rights (art. 15–21) directly on your device: Settings › Shield › Data erases everything. For any question: frost-browser@proton.me. You can also contact the CNIL (www.cnil.fr).

## Terms of use
Frost is a free browser published by Givre Studio, with no account and no advertising; using it means accepting these terms.
- Personal, free, non-exclusive and non-transferable license. The code is not published; decompiling is prohibited except as allowed by article L. 122-6-1 of the French IP Code. Only download Frost from Givre Studio's official sources.
- Updates: Frost updates itself automatically from Givre Studio's official releases. Security fixes install automatically, for your protection.
- You remain responsible for your browsing and for following the terms of the sites and services you use, including in Frost TV, which uses your own accounts.
- Local server (Ollama / third-party models): running large language models on a Mac puts heavy load on the processor, unified memory and battery. On passively cooled machines (MacBook Air) this can cause overheating, severe slowdowns or forced shutdowns. This option is for advanced users with suitable hardware (MacBook Pro with active cooling, Mac Studio, at least 16 GB of unified memory). Givre Studio accepts no liability for system instability or data loss caused by uncalibrated third-party models. Apple Intelligence remains the recommended engine.
- Frostbots answers may be inaccurate: check important information. They only act in your pages when you ask them to, never fill in passwords or payment data, and can ask for your approval before each action (Settings › Frostbots).
- Frost is provided as is; nothing limits the rights French law grants consumers.
- French law. In case of disagreement, first write to frost-browser@proton.me to find an amicable solution; failing that, the competent French courts.

## Cookies and trackers
Frost and its download pages set no measurement, advertising or social-network cookies or trackers: no consent banner is needed.
Sites you visit may set their own cookies, stored on your Mac. Frost automatically refuses consent banners, blocks third-party cookies and tracking domains, strips tracking parameters from links, sends the Global Privacy Control signal, and destroys private-browsing cookies when you close it. Settings › Shield lets you manage and erase everything.
